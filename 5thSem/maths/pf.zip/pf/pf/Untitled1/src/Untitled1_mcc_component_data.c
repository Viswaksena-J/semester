/*
 * MATLAB Compiler: 4.7 (R2007b)
 * Date: Sun Dec 21 17:15:19 2008
 * Arguments: "-B" "macro_default" "-o" "Untitled1" "-W" "WinMain:Untitled1"
 * "-d" "E:\DMS -LAB NOTES\probabilty Robotics\pf\pf\Untitled1\src" "-T"
 * "link:exe" "-v" "E:\DMS -LAB NOTES\probabilty Robotics\pf\pf\pf.m" 
 */

#include "mclmcr.h"

#ifdef __cplusplus
extern "C" {
#endif
const unsigned char __MCC_Untitled1_session_key[] = {
    '6', '0', '1', 'F', '8', 'E', '1', '9', '7', '5', 'B', 'E', '0', 'B', '0',
    '2', '7', '5', 'E', 'D', 'E', 'B', '2', 'B', '4', '3', '2', 'D', '3', '6',
    '0', 'B', 'C', '6', '8', '8', 'E', 'D', '4', '0', '7', '9', '9', '1', 'D',
    'A', 'B', '8', 'C', 'C', '5', '1', '3', '1', '5', 'C', '2', '0', '6', '4',
    '5', 'C', 'C', '6', '1', '8', '0', '7', 'D', '6', 'C', '0', '0', 'B', '4',
    '3', 'A', '1', '0', 'E', '2', 'F', '9', '9', '9', 'F', '1', 'E', '5', 'A',
    '6', '5', 'E', 'B', '5', 'A', 'C', '3', '8', '3', 'A', '0', '2', '6', '0',
    '0', 'F', 'D', '8', '4', 'B', 'F', 'E', 'B', '7', '3', '5', '4', 'B', '4',
    '6', '4', '8', 'E', 'B', 'D', 'A', '5', '3', '5', 'F', '9', '7', 'B', 'A',
    '8', '5', '2', 'D', 'B', '2', 'D', '6', 'C', '8', '5', '1', '2', 'D', 'F',
    '1', '7', '4', '3', '1', '4', '8', '2', 'F', 'F', 'E', '3', '6', 'C', 'E',
    'B', '0', 'B', 'F', 'A', '3', '7', 'F', '0', '5', 'C', '5', '3', '3', '5',
    'E', '6', 'B', '8', '2', '7', '7', '1', '7', '5', '0', 'D', '6', '1', '9',
    '1', 'B', '2', '2', '9', '2', 'A', '4', '1', '5', '2', '4', 'F', '1', '7',
    '5', 'E', '1', '0', 'C', 'F', '5', 'D', 'E', 'D', 'F', '5', '0', 'F', 'A',
    'A', 'B', 'F', '1', '2', '9', '7', '2', '4', 'E', '5', 'C', '7', 'D', '3',
    '6', '4', 'C', '3', '3', 'A', '5', '2', '7', '3', '9', 'F', '9', 'B', '7',
    '4', '\0'};

const unsigned char __MCC_Untitled1_public_key[] = {
    '3', '0', '8', '1', '9', 'D', '3', '0', '0', 'D', '0', '6', '0', '9', '2',
    'A', '8', '6', '4', '8', '8', '6', 'F', '7', '0', 'D', '0', '1', '0', '1',
    '0', '1', '0', '5', '0', '0', '0', '3', '8', '1', '8', 'B', '0', '0', '3',
    '0', '8', '1', '8', '7', '0', '2', '8', '1', '8', '1', '0', '0', 'C', '4',
    '9', 'C', 'A', 'C', '3', '4', 'E', 'D', '1', '3', 'A', '5', '2', '0', '6',
    '5', '8', 'F', '6', 'F', '8', 'E', '0', '1', '3', '8', 'C', '4', '3', '1',
    '5', 'B', '4', '3', '1', '5', '2', '7', '7', 'E', 'D', '3', 'F', '7', 'D',
    'A', 'E', '5', '3', '0', '9', '9', 'D', 'B', '0', '8', 'E', 'E', '5', '8',
    '9', 'F', '8', '0', '4', 'D', '4', 'B', '9', '8', '1', '3', '2', '6', 'A',
    '5', '2', 'C', 'C', 'E', '4', '3', '8', '2', 'E', '9', 'F', '2', 'B', '4',
    'D', '0', '8', '5', 'E', 'B', '9', '5', '0', 'C', '7', 'A', 'B', '1', '2',
    'E', 'D', 'E', '2', 'D', '4', '1', '2', '9', '7', '8', '2', '0', 'E', '6',
    '3', '7', '7', 'A', '5', 'F', 'E', 'B', '5', '6', '8', '9', 'D', '4', 'E',
    '6', '0', '3', '2', 'F', '6', '0', 'C', '4', '3', '0', '7', '4', 'A', '0',
    '4', 'C', '2', '6', 'A', 'B', '7', '2', 'F', '5', '4', 'B', '5', '1', 'B',
    'B', '4', '6', '0', '5', '7', '8', '7', '8', '5', 'B', '1', '9', '9', '0',
    '1', '4', '3', '1', '4', 'A', '6', '5', 'F', '0', '9', '0', 'B', '6', '1',
    'F', 'C', '2', '0', '1', '6', '9', '4', '5', '3', 'B', '5', '8', 'F', 'C',
    '8', 'B', 'A', '4', '3', 'E', '6', '7', '7', '6', 'E', 'B', '7', 'E', 'C',
    'D', '3', '1', '7', '8', 'B', '5', '6', 'A', 'B', '0', 'F', 'A', '0', '6',
    'D', 'D', '6', '4', '9', '6', '7', 'C', 'B', '1', '4', '9', 'E', '5', '0',
    '2', '0', '1', '1', '1', '\0'};

static const char * MCC_Untitled1_matlabpath_data[] = 
  { "Untitled1/", "toolbox/compiler/deploy/",
    "Documents and Settings/Admin/My Documents/MATLAB/Matlab2007b full/win32/java/jre/win32/jre/bin/",
    "$TOOLBOXMATLABDIR/general/", "$TOOLBOXMATLABDIR/ops/",
    "$TOOLBOXMATLABDIR/lang/", "$TOOLBOXMATLABDIR/elmat/",
    "$TOOLBOXMATLABDIR/elfun/", "$TOOLBOXMATLABDIR/specfun/",
    "$TOOLBOXMATLABDIR/matfun/", "$TOOLBOXMATLABDIR/datafun/",
    "$TOOLBOXMATLABDIR/polyfun/", "$TOOLBOXMATLABDIR/funfun/",
    "$TOOLBOXMATLABDIR/sparfun/", "$TOOLBOXMATLABDIR/scribe/",
    "$TOOLBOXMATLABDIR/graph2d/", "$TOOLBOXMATLABDIR/graph3d/",
    "$TOOLBOXMATLABDIR/specgraph/", "$TOOLBOXMATLABDIR/graphics/",
    "$TOOLBOXMATLABDIR/uitools/", "$TOOLBOXMATLABDIR/strfun/",
    "$TOOLBOXMATLABDIR/imagesci/", "$TOOLBOXMATLABDIR/iofun/",
    "$TOOLBOXMATLABDIR/audiovideo/", "$TOOLBOXMATLABDIR/timefun/",
    "$TOOLBOXMATLABDIR/datatypes/", "$TOOLBOXMATLABDIR/verctrl/",
    "$TOOLBOXMATLABDIR/codetools/", "$TOOLBOXMATLABDIR/helptools/",
    "$TOOLBOXMATLABDIR/winfun/", "$TOOLBOXMATLABDIR/demos/",
    "$TOOLBOXMATLABDIR/timeseries/", "$TOOLBOXMATLABDIR/hds/",
    "$TOOLBOXMATLABDIR/guide/", "$TOOLBOXMATLABDIR/plottools/",
    "toolbox/local/", "toolbox/comm/comm/", "toolbox/database/database/",
    "toolbox/images/images/", "toolbox/images/imuitools/",
    "toolbox/images/iptutils/", "toolbox/shared/imageslib/",
    "toolbox/images/medformats/", "toolbox/shared/spcuilib/",
    "toolbox/signal/sigtools/", "toolbox/stats/" };

static const char * MCC_Untitled1_classpath_data[] = 
  { "java/jar/toolbox/database.jar", "java/jar/toolbox/images.jar" };

static const char * MCC_Untitled1_libpath_data[] = 
  { "" };

static const char * MCC_Untitled1_app_opts_data[] = 
  { "" };

static const char * MCC_Untitled1_run_opts_data[] = 
  { "" };

static const char * MCC_Untitled1_warning_state_data[] = 
  { "off:MATLAB:dispatcher:nameConflict" };


mclComponentData __MCC_Untitled1_component_data = { 

  /* Public key data */
  __MCC_Untitled1_public_key,

  /* Component name */
  "Untitled1",

  /* Component Root */
  "",

  /* Application key data */
  __MCC_Untitled1_session_key,

  /* Component's MATLAB Path */
  MCC_Untitled1_matlabpath_data,

  /* Number of directories in the MATLAB Path */
  46,

  /* Component's Java class path */
  MCC_Untitled1_classpath_data,
  /* Number of directories in the Java class path */
  2,

  /* Component's load library path (for extra shared libraries) */
  MCC_Untitled1_libpath_data,
  /* Number of directories in the load library path */
  0,

  /* MCR instance-specific runtime options */
  MCC_Untitled1_app_opts_data,
  /* Number of MCR instance-specific runtime options */
  0,

  /* MCR global runtime options */
  MCC_Untitled1_run_opts_data,
  /* Number of MCR global runtime options */
  0,
  
  /* Component preferences directory */
  "Untitled1_E7E91AC7460329E95B636CD689C88A06",

  /* MCR warning status data */
  MCC_Untitled1_warning_state_data,
  /* Number of MCR warning status modifiers */
  1,

  /* Path to component - evaluated at runtime */
  NULL

};

#ifdef __cplusplus
}
#endif


