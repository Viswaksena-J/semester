% Image Processing Toolbox
% Version 6.0 (R2007b) 02-Aug-2007
