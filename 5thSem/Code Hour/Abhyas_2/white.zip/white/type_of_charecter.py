sample_input = input()

if sample_input.isupper():
    print("uppercase")
elif sample_input.islower():
    print("lowercase")
elif sample_input.isdigit():
    print("digit")
else:
    print(37)

