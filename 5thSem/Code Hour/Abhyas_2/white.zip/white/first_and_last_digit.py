test_cases = int(input())

for i in range(test_cases):
    sample_inputs = input()
    result = int(sample_inputs[0])+ int(sample_inputs[-1])
    print(result)