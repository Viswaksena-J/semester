A,B = map(int,input().split())

if A > B:
    print(A+B)
    print(A*B)
    print(A//B)
    print(A%B)
    print(A-B)
    print(A**B)